"""Separate support preservation on minimum one-fault placements from its full domain."""
from pathlib import Path
import hashlib
import json
import types
import zipfile

ROOT = Path(__file__).resolve().parent
archive = ROOT/'source.zip'
if hashlib.sha256(archive.read_bytes()).hexdigest() != '7b439d83ec3efdca5dd4a0a5a2455cf18e75e6117fbca3112d7ef91a22b61514':
    raise SystemExit('The pinned base archive changed')
with zipfile.ZipFile(archive) as z:
    source = z.read('zero-forcing-recovery/scripts/classification_experiment.py')
base = types.ModuleType('pinned_tree_experiment')
exec(compile(source, 'pinned-classification-experiment.py', 'exec'), base.__dict__)

n = 9
full = (1 << n)-1
infinity = n+1
edges = [(0, 1), (1, 2), (0, 3), (0, 4), (1, 5), (1, 6), (2, 7), (2, 8)]
adj = [0]*n
for a, b in edges:
    adj[a] |= 1 << b
    adj[b] |= 1 << a
times = [base.completion_time(adj, B) for B in range(1 << n)]
vertices = lambda mask: [v for v in range(n) if mask >> v & 1]


def minimum_killers(B):
    killers = [loss for loss in base.subsets(B) if times[B ^ loss] == infinity]
    size = min(loss.bit_count() for loss in killers)
    return size, [loss for loss in killers if loss.bit_count() == size]


def profile(B, allowed, maximum):
    return [max(times[B ^ loss] for loss in base.subsets(allowed) if loss.bit_count() <= k)
            for k in range(maximum+1)]


def rendered(values):
    return [None if value == infinity else value for value in values]


tolerant = [B for B in range(1 << n) if times[B] < infinity and
            all(times[B ^ (1 << v)] < infinity for v in vertices(B))]
minimum_size = min(B.bit_count() for B in tolerant)
minimum_placements = [B for B in tolerant if B.bit_count() == minimum_size]
assert minimum_size == 6 and minimum_placements == [sum(1 << v for v in range(3, 9))]
rows = []
for B in minimum_placements:
    size, killers = minimum_killers(B)
    assert size == 2 and len(killers) == 3
    global_profile = profile(B, B, size)
    supports = []
    for H in killers:
        restricted = profile(B, H, size)
        assert global_profile == restricted
        supports.append(dict(H=vertices(H), worst_times=rendered(restricted)))
    rows.append(dict(B=vertices(B), minimum_killing_size=size,
                     global_worst_times=rendered(global_profile), supports=supports))

B = full ^ 1  # All vertices except the left endpoint of the three-vertex core.
H = (1 << 7) | (1 << 8)
size, killers = minimum_killers(B)
assert size == 2 and H in killers
global_profile = profile(B, B, size)
restricted = profile(B, H, size)
assert global_profile[1] == 2 and restricted[1] == 1
actual, witness, checked_B, checked_H = base.every_minimum_support(adj)
assert actual is False

result = dict(status='minimum_one_fault_domain_strictly_weaker_verified_on_example',
    graph='Three-vertex path core, with two pendant leaves at every core vertex',
    vertices=n, edges=edges, all_initial_colourings_enumerated=1 << n,
    one_fault_tolerant_placements=len(tolerant), minimum_one_fault_size=minimum_size,
    all_minimum_one_fault_placements=rows,
    support_comparison_for_all_minimum_one_fault_placements=True,
    every_minimum_support=False,
    explicit_counterexample=dict(B=vertices(B), H=vertices(H), minimum_killing_size=size,
        budgets=list(range(size+1)), global_worst_times=rendered(global_profile),
        support_worst_times=rendered(restricted), separating_budget=1, separating_deadline=1),
    infinity_encoding_in_report=None,
    all_budgets_reduction='At or above the minimum killing size both profiles are infinite.',
    finite_evidence_only=True, novelty_claimed=False,
    base_simulator_sha256=hashlib.sha256(source).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out = ROOT/'build/domain-separation.json'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
