import ZeroForcingRecovery

set_option autoImplicit false

noncomputable section
namespace FaultObservationResearch.SemanticComparison

universe u
variable {V : Type u} [Fintype V] [DecidableEq V]

/-- Restricting the initial set to an inclusion-minimal forcing set
    makes every minimum killing set have size at most one. -/
theorem minimumKilling_card_le_one_of_inclusion_minimal_initial
    (adj : V → V → Prop) (blue support : Finset V)
    (hblue : IsForcing adj blue)
    (hminimal : ∀ smaller : Finset V, smaller ⊂ blue → ¬ IsForcing adj smaller)
    (hminimum : IsMinimumKilling adj blue support) : support.card ≤ 1 := by
  classical
  have hnonempty : support.Nonempty := by
    by_contra h
    have he : support = ∅ := Finset.not_nonempty_iff_eq_empty.mp h
    exact hminimum.2.1 (by simpa [he] using hblue)
  obtain ⟨v, hv⟩ := hnonempty
  have hvblue : v ∈ blue := hminimum.1 hv
  have hfailed : ¬ IsForcing adj (blue \ {v}) := by
    simpa only [Finset.sdiff_singleton_eq_erase] using
      hminimal (blue.erase v) (Finset.erase_ssubset hvblue)
  have hsubset : ({v} : Finset V) ⊆ blue := by simpa using hvblue
  have hcard := (IsMinimumKilling_iff_card_minimum adj blue support).mp hminimum
  simpa only [Finset.card_singleton] using hcard.2.2 {v} hsubset hfailed

/-- With an inclusion-minimal initial set, all budget/deadline comparisons
    hold on every finite model, independently of its graph structure. -/
theorem support_comparison_of_inclusion_minimal_initial
    (adj : V → V → Prop) (blue support : Finset V)
    (hblue : IsForcing adj blue)
    (hminimal : ∀ smaller : Finset V, smaller ⊂ blue → ¬ IsForcing adj smaller)
    (hminimum : IsMinimumKilling adj blue support) (budget deadline : ℕ) :
    RobustBy adj blue blue budget deadline ↔
      RobustBy adj blue support budget deadline := by
  exact robustBy_iff_of_minimum_card_le_one adj blue support hminimum
    (minimumKilling_card_le_one_of_inclusion_minimal_initial
      adj blue support hblue hminimal hminimum) budget deadline

/-- A cardinality-minimum forcing set is inclusion-minimal. -/
theorem inclusion_minimal_of_cardinality_minimum_initial
    (adj : V → V → Prop) (blue : Finset V)
    (hcard : ∀ other : Finset V, IsForcing adj other → blue.card ≤ other.card) :
    ∀ smaller : Finset V, smaller ⊂ blue → ¬ IsForcing adj smaller := by
  intro smaller hproper hforcing
  exact Nat.not_lt_of_ge (hcard smaller hforcing) (Finset.card_lt_card hproper)

/-- The version restricted to cardinality-minimum initial forcing sets
    is automatic and cannot classify the original EveryMinimumSupport property. -/
theorem support_comparison_of_cardinality_minimum_initial
    (adj : V → V → Prop) (blue support : Finset V)
    (hblue : IsForcing adj blue)
    (hcard : ∀ other : Finset V, IsForcing adj other → blue.card ≤ other.card)
    (hminimum : IsMinimumKilling adj blue support) (budget deadline : ℕ) :
    RobustBy adj blue blue budget deadline ↔
      RobustBy adj blue support budget deadline := by
  exact support_comparison_of_inclusion_minimal_initial adj blue support hblue
    (inclusion_minimal_of_cardinality_minimum_initial adj blue hcard)
    hminimum budget deadline

/-- A minimum-cardinality one-loss-tolerant placement is a different domain:
    its minimum killing sets have size two, rather than one. -/
theorem minimumKilling_card_two_of_minimum_one_loss_tolerant_initial
    (adj : V → V → Prop) (blue support : Finset V)
    (htolerant : ∀ loss : Finset V, loss ⊆ blue → loss.card ≤ 1 →
      IsForcing adj (blue \ loss))
    (hcard : ∀ other : Finset V,
      (∀ loss : Finset V, loss ⊆ other → loss.card ≤ 1 → IsForcing adj (other \ loss)) →
        blue.card ≤ other.card)
    (hminimum : IsMinimumKilling adj blue support) : support.card = 2 := by
  classical
  have hlower : 2 ≤ support.card := by
    by_contra h
    have hsmall : support.card ≤ 1 := by omega
    exact hminimum.2.1 (htolerant support hminimum.1 hsmall)
  have hupper : support.card ≤ 2 := by
    by_contra h
    have hlarge : 2 < support.card := by omega
    have hnonempty : support.Nonempty := Finset.card_pos.mp (by omega)
    obtain ⟨v, hv⟩ := hnonempty
    have hvblue : v ∈ blue := hminimum.1 hv
    have herase : ∀ loss : Finset V, loss ⊆ blue.erase v → loss.card ≤ 1 →
        IsForcing adj (blue.erase v \ loss) := by
      intro loss hsubset hsize
      have hsubset' : insert v loss ⊆ blue := by
        intro x hx
        rcases Finset.mem_insert.mp hx with hx | hx
        · simpa only [hx] using hvblue
        · exact Finset.mem_of_mem_erase (hsubset hx)
      have hsize' : (insert v loss).card < support.card := by
        have hi := Finset.card_insert_le v loss
        omega
      have hforce := hminimum.2.2 (insert v loss) hsubset' hsize'
      have heq : blue.erase v \ loss = blue \ insert v loss := by
        ext x
        simp only [Finset.mem_sdiff, Finset.mem_erase, Finset.mem_insert]
        tauto
      rwa [heq]
    exact Nat.not_lt_of_ge (hcard (blue.erase v) herase)
      (Finset.card_lt_card (Finset.erase_ssubset hvblue))
  exact Nat.le_antisymm hupper hlower

#check @support_comparison_of_inclusion_minimal_initial
#check @support_comparison_of_cardinality_minimum_initial
#check @minimumKilling_card_two_of_minimum_one_loss_tolerant_initial
#print axioms minimumKilling_card_le_one_of_inclusion_minimal_initial
#print axioms support_comparison_of_inclusion_minimal_initial
#print axioms inclusion_minimal_of_cardinality_minimum_initial
#print axioms support_comparison_of_cardinality_minimum_initial
#print axioms minimumKilling_card_two_of_minimum_one_loss_tolerant_initial

end FaultObservationResearch.SemanticComparison
