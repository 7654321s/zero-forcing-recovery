"""Verify the sealed comparison packet; generated build outputs are excluded."""
from pathlib import Path
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
expected = {row['path']: row for row in manifest['files']}
actual = set()
for directory, folders, files in os.walk(ROOT):
    folders[:] = [n for n in folders if n not in {'build', '__pycache__'}]
    for name in files:
        path = Path(directory)/name
        if path.is_symlink():
            raise SystemExit('Unexpected symlink: '+str(path))
        if path != ROOT/'manifest.json':
            actual.add(path.relative_to(ROOT).as_posix())
if actual != set(expected):
    raise SystemExit('Packet inventory differs')
for name, row in expected.items():
    data = (ROOT/name).read_bytes()
    if hashlib.sha256(data).hexdigest() != row['sha256'] or len(data) != row['bytes']:
        raise SystemExit('Changed packet file: '+name)
print(json.dumps(dict(status='comparison_packet_integrity_verified', files=len(expected),
                     base_version='1.0.1', supplementary_theorems=5), indent=2))
