"""Reproduce the five comparison lemmas using the pinned v1.0.1 proof sources."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
BASE_SHA = '7b439d83ec3efdca5dd4a0a5a2455cf18e75e6117fbca3112d7ef91a22b61514'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, help='An already built v1.0.1 project; otherwise extract and build the supplied archive')
    parser.add_argument('--lake', default='lake', help='Lake executable for Lean 4.35.0')
    parser.add_argument('--work-dir', type=Path, help='Optional shorter directory for generated build outputs')
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    out = (args.work_dir.resolve() if args.work_dir else ROOT/'build')/stamp
    out.mkdir(parents=True)
    summary = dict(status='running', reused_built_base=bool(args.project), steps=[],
                   base_proof_modules=71, supplementary_theorems=5, novelty_claimed=False)

    def save():
        (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')

    def step(label, command, project):
        print('Starting '+label, flush=True)
        log = out/(label+'.log')
        with log.open('w', encoding='utf-8') as stream:
            child = subprocess.run(command, cwd=project, stdout=stream, stderr=subprocess.STDOUT)
        summary['steps'].append(dict(label=label, command=command, exit_code=child.returncode,
                                     log=log.name, log_sha256=digest(log)))
        save()
        if child.returncode:
            raise RuntimeError(label+' failed; see '+str(log))
        return log.read_text(encoding='utf-8')

    save()
    try:
        archive = ROOT/'source.zip'
        if digest(archive) != BASE_SHA:
            raise ValueError('The supplied base archive changed')
        project = args.project.resolve() if args.project else out/'base'
        with zipfile.ZipFile(archive) as z:
            snapshot = json.loads(z.read('zero-forcing-recovery/verification/verified-snapshot.json'))
            if not args.project:
                project.mkdir()
                for name in z.namelist():
                    relative = PurePosixPath(name).relative_to('zero-forcing-recovery')
                    if relative.is_absolute() or '..' in relative.parts:
                        raise ValueError('Invalid archive path')
                    target = project.joinpath(*relative.parts)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(z.read(name))
        if len(snapshot['sources']) != 71:
            raise ValueError('Unexpected proof inventory')
        for row in snapshot['sources']:
            if digest(project/row['file']) != row['sha256']:
                raise ValueError('Base proof changed: '+row['file'])
        if not args.project:
            step('dependencies', [args.lake, 'update'], project)
            step('cache', [args.lake, 'exe', 'cache', 'get'], project)
            step('base-build', [args.lake, '--no-ansi', '--wfail', 'build'], project)
        version = step('version', [args.lake, 'env', 'lean', '--short-version'], project)
        if version.strip() != '4.35.0':
            raise ValueError('Expected Lean 4.35.0')
        helper = ROOT/'MinimalInitial.lean'
        command = [args.lake, 'env', 'lean', '--root='+str(ROOT), '-o', str(out/'MinimalInitial.olean'), str(helper)]
        log = step('comparison', command, project)
        found = {m[1]: [a.strip() for a in m[2].split(',') if a.strip()]
                 for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", log)}
        found.update({m[1]: [] for m in re.finditer(r"'([^']+)' does not depend on any axioms", log)})
        if len(found) != 5 or any(not set(axioms) <= ALLOWED for axioms in found.values()):
            raise ValueError('Unexpected axiom audit')
        if 'warning:' in log or 'error:' in log:
            raise ValueError('Lean emitted a warning or error')
        summary.update(status='passed', audited_declarations=found,
                       source_sha256=digest(helper), olean_sha256=digest(out/'MinimalInitial.olean'))
    except Exception as exc:
        summary.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    save()
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if summary['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
