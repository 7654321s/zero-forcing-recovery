"""Resume the preserved bootstrap and record fresh project builds separately."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time,traceback

ROOT=Path(__file__).resolve().parent.parent
PROJECT=Path('E:/zf-quantifier-repro/20261117T151452_429239Z/base')
PACKET=ROOT/'deliveries/20261117-quantifier-comparison'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
RUN=ROOT/'runs'/(stamp+'-quantifier-bootstrap-recovery');RUN.mkdir()
shutil.copy2(Path(__file__),RUN/Path(__file__).name)
base=read(ROOT/'runs/20261117T123003_387036Z-clean-reproduction/run_summary.json')
bin_dir=Path(base['workspace'])/'toolchain/lean-4.35.0-windows/bin'
lake=str(bin_dir/'lake.exe')
state=dict(status='running',run=str(RUN.relative_to(ROOT)),project=str(PROJECT),steps=[],
    initial_bootstrap_failure_preserved=True,compiler_reused=True,
    existing_compressed_official_mathlib_cache_reused=True,project_precompiled_proofs_reused=False,
    same_windows_host=True,separate_machine=False,separate_os_or_vm=False,
    tls_verification_enabled=True,git_tls_backend='schannel',http_version='HTTP/1.1',
    global_configuration_modified=False,github_upload_performed=False,
    independent_human_review=False,novelty_confirmed=False)

def save():
    (RUN/'run_summary.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
    (ROOT/'data/quantifier_bootstrap_recovery_latest_20261117.json').write_text(json.dumps(dict(
        status=state['status'],run=str(RUN/'run_summary.json'),project=str(PROJECT)),indent=2)+'\n',encoding='utf-8')

env={k:v for k,v in os.environ.items() if not k.upper().startswith(('LEAN_','LAKE_','ELAN_','MATHLIB_','GIT_CONFIG_'))
     and k.upper()!='GIT_SSL_NO_VERIFY'}
env.update(base['task_local_cache_directories']);env['PATH']=str(bin_dir)+os.pathsep+env['PATH']
env.update(LEAN_NUM_THREADS='2',PYTHONUTF8='1',GIT_CONFIG_GLOBAL=str(Path(base['workspace'])/'empty-git-config'),
    GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never',GIT_CONFIG_COUNT='3',
    GIT_CONFIG_KEY_0='http.sslBackend',GIT_CONFIG_VALUE_0='schannel',
    GIT_CONFIG_KEY_1='http.sslVerify',GIT_CONFIG_VALUE_1='true',
    GIT_CONFIG_KEY_2='http.version',GIT_CONFIG_VALUE_2='HTTP/1.1')

def step(label,command,timeout):
    state['current_step']=label;save();print('Starting '+label,flush=True)
    log=RUN/(label+'.log');start=time.monotonic();timed_out=False
    with log.open('w',encoding='utf-8') as out:
        child=subprocess.Popen(command,cwd=PROJECT,env=env,stdout=out,stderr=subprocess.STDOUT)
        state['current_child_pid']=child.pid;save()
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            if child.poll() is None:
                subprocess.run(['taskkill.exe','/PID',str(child.pid),'/T','/F'],capture_output=True)
            code=child.wait(timeout=20)
    state['steps'].append(dict(label=label,command=command,exit_code=code,timed_out=timed_out,
        log=log.name,log_sha256=sha(log),elapsed_seconds=time.monotonic()-start))
    state.pop('current_child_pid',None);save();print(label+' exit '+str(code),flush=True)
    if code or timed_out:raise RuntimeError(label+' failed; inspect '+str(log))

save()
try:
    assert read(PROJECT.parent/'summary.json')['status']=='failed'
    assert sha(PACKET/'source.zip')=='7b439d83ec3efdca5dd4a0a5a2455cf18e75e6117fbca3112d7ef91a22b61514'
    original=read(PROJECT/'lake-manifest.json')
    before=list((PROJECT/'.lake/build/lib/lean').glob('formalization*.olean'))
    state['initial_project_proof_oleans']=len(before);assert not before
    step('dependencies',[lake,'--no-ansi','update'],180)
    locked=read(PROJECT/'lake-manifest.json')
    assert {p['name']:p['rev'] for p in locked['packages']}=={p['name']:p['rev'] for p in original['packages']}
    state['dependency_checkouts']=[]
    for package in locked['packages']:
        path=PROJECT/'.lake/packages'/package['name']
        assert not path.is_symlink() and not getattr(path,'is_junction',lambda:False)()
        head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,env=env,text=True).strip()
        assert head==package['rev']
        state['dependency_checkouts'].append(dict(name=package['name'],rev=head))
    save()
    step('official-cache',[lake,'exe','cache','get'],300)
    step('base-source-build',[lake,'--no-ansi','--wfail','build'],1800)
    step('base-axiom-audit',[sys.executable,'-X','utf8','scripts/audit_axioms.py','--lake',lake],120)
    audit=read(PROJECT/'build/audit/result.json')
    assert audit['status']=='passed' and audit['source_modules']==71 and audit['checked_declarations']==511
    start_outputs=set((PACKET/'build').glob('*/summary.json')) if (PACKET/'build').exists() else set()
    step('supplement-reproduction',[sys.executable,'-X','utf8',str(PACKET/'reproduce.py'),
        '--project',str(PROJECT),'--lake',lake],120)
    new_outputs=set((PACKET/'build').glob('*/summary.json'))-start_outputs
    assert len(new_outputs)==1
    helper_path=new_outputs.pop();helper=read(helper_path)
    assert helper['status']=='passed' and len(helper['audited_declarations'])==5
    shutil.copytree(helper_path.parent,RUN/'supplement-reproduction')
    for row in read(PROJECT/'verification/verified-snapshot.json')['sources']:
        assert sha(PROJECT/row['file'])==row['sha256']
    state.update(status='preserved_fresh_bootstrap_recovered_and_fully_verified',
        base_source_modules=71,base_axiom_declarations=511,supplementary_declarations=5,
        base_source_build_warning_free='warning:' not in (RUN/'base-source-build.log').read_text(encoding='utf-8'),
        helper_summary_sha256=sha(helper_path))
    assert state['base_source_build_warning_free']
    save();print('Bootstrap recovery completed',flush=True)
except BaseException as exc:
    state.update(status='failed_preserved_for_diagnosis',error_type=type(exc).__name__,error=str(exc))
    save();traceback.print_exc();sys.exit(1)
